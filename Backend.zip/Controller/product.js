const Product = require('../Models/product');

// PostProduct

exports.postProduct = (req, res, next) => {
    new Product({
        productname: req.body.productname,
        category: req.body.category,
        company: req.body.company,
        quantity: req.body.quantity,
        price: req.body.price
    }).save().then(data => {
        console.log(data)
        res.json(data);
    }).catch(err => {
        console.log(err);
    })
}

// GetProduct

exports.getProduct = (req, res, next) => {
    Product.find().then(data => {
        res.json(data);
    }).catch(err => {
        console.log(err);
    });
}

//Update

exports.updateProduct = (req, res) => {
    let id = req.body.id;
    let productname = req.body.productname;
    let category = req.body.category;
    let company = req.body.company;
    let quantity = req.body.quantity;
    let price = req.body.price;
    Product.findById(id).then(prod => {
        prod.productname = productname;
        prod.category = category;
        prod.company = company;
        prod.quantity = quantity;
        prod.price = price;
        prod.save();
        return res.json(prod);

    }).catch(err => {
        console.log(err)
    })
}


exports.deleteProducts = (req, res, next) => {
    let id = req.params.id;
    Product.findByIdAndRemove(id).then(result => {
        res.json(result);
    }).catch(err => {
        console.log(err);
    })
}