const express = require('express');
const router = express.Router();
const adminReqController = require('../Controller/product');

// PostProduct

router.post('/postProduct', adminReqController.postProduct);

// GetProduct 

router.get('/getProduct', adminReqController.getProduct);

router.post('/updateProduct', adminReqController.updateProduct);

router.delete('/deleteProduct/:id', adminReqController.deleteProducts);



module.exports = router;