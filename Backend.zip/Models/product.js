const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let reqSchema = new Schema({
    productname: {
        type: String
    },
    category: {
        type: String
    },
    company: {
        type: String
    },
    quantity: {
        type: Number
    },
    price: {
        type: Number
    },

})


module.exports = mongoose.model('Product', reqSchema);